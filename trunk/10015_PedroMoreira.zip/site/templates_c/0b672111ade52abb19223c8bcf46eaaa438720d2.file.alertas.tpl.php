<?php /* Smarty version Smarty-3.1.14, created on 2013-08-26 12:59:15
         compiled from "./templates/alertas.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6798067251f668b9ae99c5-40766409%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0b672111ade52abb19223c8bcf46eaaa438720d2' => 
    array (
      0 => './templates/alertas.tpl',
      1 => 1375099359,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6798067251f668b9ae99c5-40766409',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_51f668b9aeafd1_60274576',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51f668b9aeafd1_60274576')) {function content_51f668b9aeafd1_60274576($_smarty_tpl) {?>ZONA DE ALERTAS<?php }} ?>