<?php /* Smarty version Smarty-3.1.14, created on 2013-08-26 12:59:15
         compiled from "./templates/identificacao.tpl" */ ?>
<?php /*%%SmartyHeaderCode:140289562951f668b9ae2848-14487247%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6c73e6bf37e4d683c493da895f6a194b10c8faef' => 
    array (
      0 => './templates/identificacao.tpl',
      1 => 1375099322,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '140289562951f668b9ae2848-14487247',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_51f668b9ae6ff0_66944714',
  'variables' => 
  array (
    'username' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51f668b9ae6ff0_66944714')) {function content_51f668b9ae6ff0_66944714($_smarty_tpl) {?><?php echo $_smarty_tpl->tpl_vars['username']->value;?>
<?php }} ?>