<?php /* Smarty version Smarty-3.1.14, created on 2013-08-26 12:45:56
         compiled from "./templates/teacher_menu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1651292861521b3ff40e7761-81257312%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0409be10005a944eb90376021407f4922e90b560' => 
    array (
      0 => './templates/teacher_menu.tpl',
      1 => 1377516765,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1651292861521b3ff40e7761-81257312',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_521b3ff40e8f02_65427766',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_521b3ff40e8f02_65427766')) {function content_521b3ff40e8f02_65427766($_smarty_tpl) {?><a href="?User&newEvaluation">nova avalia&ccedil;&atilde;o</a><?php }} ?>