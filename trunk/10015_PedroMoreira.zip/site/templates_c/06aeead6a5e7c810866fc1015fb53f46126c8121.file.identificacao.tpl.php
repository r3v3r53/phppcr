<?php /* Smarty version Smarty-3.1.13, created on 2013-07-13 17:49:03
         compiled from ".\templates\identificacao.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1355851e184fff0e094-20903106%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '06aeead6a5e7c810866fc1015fb53f46126c8121' => 
    array (
      0 => '.\\templates\\identificacao.tpl',
      1 => 1373723733,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1355851e184fff0e094-20903106',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'username' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_51e184fff14ad0_06674889',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51e184fff14ad0_06674889')) {function content_51e184fff14ad0_06674889($_smarty_tpl) {?><?php echo $_smarty_tpl->tpl_vars['username']->value;?>
<?php }} ?>