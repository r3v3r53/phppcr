<?php /* Smarty version Smarty-3.1.13, created on 2013-07-17 08:59:34
         compiled from "./templates/detalhes.tpl" */ ?>
<?php /*%%SmartyHeaderCode:185474464451e47b967222c9-83839980%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '759f3dd4d0095ca32040b7a766d5548d3ca717b7' => 
    array (
      0 => './templates/detalhes.tpl',
      1 => 1374022851,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '185474464451e47b967222c9-83839980',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_51e47b967238b3_59459103',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51e47b967238b3_59459103')) {function content_51e47b967238b3_59459103($_smarty_tpl) {?>detalhes do dia<?php }} ?>