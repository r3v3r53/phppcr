<?php /* Smarty version Smarty-3.1.13, created on 2013-07-13 17:49:04
         compiled from ".\templates\detalhes.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1088251e185000b8c40-59209241%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6d71f1b32a9c8be4f940138609b28b4ccd7bf07c' => 
    array (
      0 => '.\\templates\\detalhes.tpl',
      1 => 1373492482,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1088251e185000b8c40-59209241',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_51e18500131ee5_41941794',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51e18500131ee5_41941794')) {function content_51e18500131ee5_41941794($_smarty_tpl) {?>detalhes do dia<?php }} ?>