<?php /* Smarty version Smarty-3.1.13, created on 2013-07-17 11:27:34
         compiled from "./templates/teste.tpl" */ ?>
<?php /*%%SmartyHeaderCode:191900941551e67196ef5119-77182627%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ca5e11081b2bc21e7f91fbd327cb8de73d587502' => 
    array (
      0 => './templates/teste.tpl',
      1 => 1374056776,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '191900941551e67196ef5119-77182627',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'teste' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_51e6719700e7d5_42329084',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51e6719700e7d5_42329084')) {function content_51e6719700e7d5_42329084($_smarty_tpl) {?><hr>
<?php echo $_smarty_tpl->tpl_vars['teste']->value;?>

<hr><?php }} ?>