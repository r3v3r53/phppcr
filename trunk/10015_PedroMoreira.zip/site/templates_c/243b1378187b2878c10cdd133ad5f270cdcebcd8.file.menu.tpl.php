<?php /* Smarty version Smarty-3.1.14, created on 2013-08-26 12:22:26
         compiled from "./templates/menu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16050269851e47b96671dd1-74882621%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '243b1378187b2878c10cdd133ad5f270cdcebcd8' => 
    array (
      0 => './templates/menu.tpl',
      1 => 1377516137,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16050269851e47b96671dd1-74882621',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_51e47b96673483_88663804',
  'variables' => 
  array (
    'menu' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51e47b96673483_88663804')) {function content_51e47b96673483_88663804($_smarty_tpl) {?><?php echo $_smarty_tpl->tpl_vars['menu']->value;?>
<?php }} ?>