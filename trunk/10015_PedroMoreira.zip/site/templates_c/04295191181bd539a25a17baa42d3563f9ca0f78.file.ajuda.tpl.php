<?php /* Smarty version Smarty-3.1.13, created on 2013-07-13 17:49:03
         compiled from ".\templates\ajuda.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1999551e184ffe051e4-56944446%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '04295191181bd539a25a17baa42d3563f9ca0f78' => 
    array (
      0 => '.\\templates\\ajuda.tpl',
      1 => 1373492483,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1999551e184ffe051e4-56944446',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_51e184ffe85360_83779931',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51e184ffe85360_83779931')) {function content_51e184ffe85360_83779931($_smarty_tpl) {?><a href="#">Ajuda</a><?php }} ?>