<?php /* Smarty version Smarty-3.1.14, created on 2013-08-26 12:59:15
         compiled from "./templates/b_login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:39294477851f668b9a9ee29-55223964%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bb573b97cd6681593788d5a7b82f032bf9c44029' => 
    array (
      0 => './templates/b_login.tpl',
      1 => 1375099266,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '39294477851f668b9a9ee29-55223964',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_51f668b9add298_33256550',
  'variables' => 
  array (
    'login_action' => 0,
    'titulo_botao_login' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51f668b9add298_33256550')) {function content_51f668b9add298_33256550($_smarty_tpl) {?><a href="<?php echo $_smarty_tpl->tpl_vars['login_action']->value;?>
" title="<?php echo $_smarty_tpl->tpl_vars['titulo_botao_login']->value;?>
" id="<?php echo $_smarty_tpl->tpl_vars['titulo_botao_login']->value;?>
" >
				<?php echo $_smarty_tpl->tpl_vars['titulo_botao_login']->value;?>

			</a><?php }} ?>