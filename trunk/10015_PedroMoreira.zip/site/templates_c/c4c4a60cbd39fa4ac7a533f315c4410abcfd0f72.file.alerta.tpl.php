<?php /* Smarty version Smarty-3.1.13, created on 2013-07-13 17:49:04
         compiled from ".\templates\alerta.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1253551e18500001530-15777621%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c4c4a60cbd39fa4ac7a533f315c4410abcfd0f72' => 
    array (
      0 => '.\\templates\\alerta.tpl',
      1 => 1373492483,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1253551e18500001530-15777621',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_51e1850000c762_82739364',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51e1850000c762_82739364')) {function content_51e1850000c762_82739364($_smarty_tpl) {?>A CARREGAR INFORMA&Ccedil;&Atilde;O<?php }} ?>