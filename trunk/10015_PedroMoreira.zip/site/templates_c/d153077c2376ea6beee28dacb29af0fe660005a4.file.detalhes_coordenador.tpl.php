<?php /* Smarty version Smarty-3.1.13, created on 2013-07-17 14:23:09
         compiled from "./templates/detalhes_coordenador.tpl" */ ?>
<?php /*%%SmartyHeaderCode:130341880151e69abd0800e6-04013209%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd153077c2376ea6beee28dacb29af0fe660005a4' => 
    array (
      0 => './templates/detalhes_coordenador.tpl',
      1 => 1374056939,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '130341880151e69abd0800e6-04013209',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_51e69abd081994_39225123',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51e69abd081994_39225123')) {function content_51e69abd081994_39225123($_smarty_tpl) {?><hr>
Coordenador
<hr><?php }} ?>