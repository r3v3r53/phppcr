<?php /* Smarty version Smarty-3.1.14, created on 2013-08-26 12:57:28
         compiled from "./templates/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:538999749521b34983e14e2-95053129%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3a4f6f0d327fc7bc3ea86f63906a1bf934ca50c7' => 
    array (
      0 => './templates/footer.tpl',
      1 => 1377512771,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '538999749521b34983e14e2-95053129',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_521b34983e4396_18536493',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_521b34983e4396_18536493')) {function content_521b34983e4396_18536493($_smarty_tpl) {?></BODY>
</HTML>
<?php }} ?>