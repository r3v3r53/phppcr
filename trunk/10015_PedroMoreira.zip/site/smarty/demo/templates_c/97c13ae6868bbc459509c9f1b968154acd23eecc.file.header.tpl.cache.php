<?php /* Smarty version Smarty-3.1.14, created on 2013-08-26 12:57:28
         compiled from "./templates/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:536752367521b34983aec34-27201909%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '97c13ae6868bbc459509c9f1b968154acd23eecc' => 
    array (
      0 => './templates/header.tpl',
      1 => 1377512771,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '536752367521b34983aec34-27201909',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'title' => 0,
    'Name' => 1,
  ),
  'has_nocache_code' => true,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_521b34983bb3f5_45335809',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_521b34983bb3f5_45335809')) {function content_521b34983bb3f5_45335809($_smarty_tpl) {?><HTML>
<HEAD>
<TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo '/*%%SmartyNocache:536752367521b34983aec34-27201909%%*/<?php echo $_smarty_tpl->tpl_vars[\'Name\']->value;?>
/*/%%SmartyNocache:536752367521b34983aec34-27201909%%*/';?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }} ?>