<?php
#error_reporting(1);
#error_reporting(E_ALL);
#ini_set('display_errors', '1');

require_once("controller/MainController.php");
$avaliacoes = new MainController();
?>